# Connect-CMS YuyuQuizzes

Connect-CMS向けの非公式小テストプラグイン「YuyuQuizzes」です。小テストの作成、受験、自動採点・手動採点、結果集計、CSV出力、カテゴリー別評価を提供します。

> バージョン: 0.9.0-beta.5
> 開発・提供: ゆうゆう企画  
> 状態: ベータ版

## 主な機能

- 単一選択、複数選択、短答、複数短答、記述式（文字入力・手書き）
- 回答の途中保存、再開、提出
- 自動採点と記述式の手動採点
- 個人結果、受験集団の結果、得点分布
- 小問別反応表、SP表、カテゴリー別結果のCSV出力
- カテゴリー別評価とレーダーチャート
- MathJaxによる数式表示
- 小テスト一式の共有・複製
- モデレータによる管理者向け結果閲覧・CSV出力

## 対応確認環境

- Connect-CMS 1.39.0
- PHP 8.1

本配布物は新規インストール用です。既存のQuizzes環境の更新には使用しないでください。

必ず検証環境で確認してから利用してください。本番環境へ導入する前に、ファイルとデータベースのバックアップを取得してください。

## ソースコード

標準版の実ファイルは、GitHub上で直接閲覧できます。

- [プラグイン本体](app/Plugins/User/Yuyuquizzes)
- [Model](app/Models/User/YuyuQuizzes)
- [Migration](database/migrations)
- [画面テンプレート](resources/views/plugins/user/yuyuquizzes)

ルート直下の`app`、`database`、`resources`は、Connect-CMSへ重ねて配置するディレクトリ構成と同じです。配布用の標準ZIPも、このソースコードから生成します。

## ダウンロード

次の配布用ZIPをダウンロードしてください。

- [標準版 connect-cms-yuyuquizzes-0.9.0-beta.5.zip](downloads/connect-cms-yuyuquizzes-0.9.0-beta.5.zip)
- [数式入力支援オプション connect-cms-yuyuquizzes-math-editor-tools-option-0.9.0-beta.4.zip](downloads/connect-cms-yuyuquizzes-math-editor-tools-option-0.9.0-beta.4.zip)

標準版だけでも、WYSIWYGへLaTeXコードを直接入力してMathJaxで表示できます。オプション版は、数式入力ダイアログ、プレビュー、挿入ボタンを追加する場合だけ導入します。

## インストール

1. Connect-CMSのファイルとデータベースをバックアップします。
2. 標準版ZIPを展開します。
3. ZIP内の`app`、`resources`、`database`をConnect-CMSのルートへ配置します。
4. Connect-CMSのルートで`php artisan migrate`を実行します。
5. 必要に応じて`php artisan view:clear`を実行します。
6. 管理画面で既存の小テストフレームがYuyuQuizzesとして表示されることを確認します。


オプション版はConnect-CMSの共通WYSIWYGを上書きします。導入前に`resources/views/plugins/common/wysiwyg.blade.php`を必ずバックアップしてください。

## 権限

- モデレータ: 管理者向け結果の閲覧、CSV出力
- コンテンツ管理者: 設定、問題作成・編集、手動採点、およびモデレータの機能

## ベータ版の注意

- 評価・検証を目的としたベータ版です。
- 不具合時に復元できる環境で利用してください。
- 非会員受験、公開承認ワークフロー、多言語対応は含みません。

## ライセンス・免責

MIT Licenseで提供します。

本プラグインは、株式会社オープンソース・ワークショップが公式に提供、認定または保証するものではありません。Connect-CMS本体の著作権とライセンスは、配布元の条件に従います。

## 開発支援

設計、実装およびコードレビューにはChatGPT（OpenAI）による開発支援を利用しています。仕様決定、動作確認、公開および保守の責任は、開発・提供者が負います。
